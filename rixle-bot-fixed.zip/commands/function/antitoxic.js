
module.exports = { 
name: "antitoxic",  
async functions(m) { 
let { conn, text } = data
if (/^(kntl(bacot(anj?ing?Ng)asu)kanjut)/i.test(m.text)) {
m.reply('Terdeteksi Menggunakan bahasa Toxic')
}
}
}

