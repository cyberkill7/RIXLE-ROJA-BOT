red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
reset='\033[0m'

clear
apt install ffmpeg imagemagick nodejs neofetch 
npm i
npm start
printf "$yellow Startring..."
