userdata = {
exp: 0,
limit: 1000,
role: "Bronze",
level: 1,
}
