<p align="center">
	<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrF6fyFoGCHmsmOXWjFxIXh-467D1nRhA4mQ&usqp=CAU" width="75%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<p align="center">
<a href="#"><img title="RIXLE - BOT" src="https://img.shields.io/badge/RixleBot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Rizxyu"><img title="Fauzan" src="https://img.shields.io/badge/Author-Rizky-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
</p>
</div>
<p align="center">
<a href="https://github.com/Rizxyu/followers"><img title="Followers" src="https://img.shields.io/github/followers/Rizxyu?style=flat-square"></a>
<a href="https://github.com/Rizxyu/RIXLE-BOT/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/Rizxyu/RIXLE-BOT?style=flat-square"></a>
<a href="https://github.com/Rizxyu/RIXLE-BOT/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Rizxyu/RIXLE-BOT?style=flat-square"></a>
<a href="https://github.com/Rizxyu/RIXLE-BOT/watchers"><img title="watchers" src="https://img.shields.io/github/watchers/Rizxyu/RIXLE-BOT?style=flat-square"></a>
</p>

```js
Script ini dirancang untuk pengguna rdp/Nodejs/Linux/Railway/heroku/replit
```
```js 
Lu gausah asal claim sc ini, ganti nama/up di yt atas nama lu, sama aja lu ga ngehargai kita sebagai pembuat sc ini, mohon di mengerti!
```

# Join Group
[![Group Bot](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/EBI5SZfyE8Z6i4UJpcs9Tl)

# ONLY RUN RAILWAY
[`railway.app`](https://railway.app/new/github)
## REST API
**[`Riz Api`](https://rizapi.herokuapp.com/)**

## ✍️ Editing the file

Edit the required value in [`config.js`](https://github.com/Rizxyu/RIXLE-BOT/blob/main/config.js)

Create a new account at [`monggodb`](https://www.mongodb.com/cloud/atlas/register)


# KHUSUS TERMUX↓
[`githubdl`](https://github.com/Fau-Zan/Rixle-botV2)

# RDP/VPS/LINUX


## FEATURE LIST 💡

| FEATURE |🌱|
| ------------- | ------------- |
| Anti Toxic|✅|
| Anti Troli|✅|
| Anti Virtex|✅|
| Anti Spam|✅|
| Anti Link Group|✅|
| Anti Link Telegram|✅|
| Anti Link Youtube Channel|✅|
| Anti Link Youtube Video|✅|
| Anti Link Instagram|✅|
| Anonymous Chat|✅|

| GRUP |👥|
| ------------- | ------------- |
| Join|✅|
| add|✅|
| open gc|✅|
| Close gc|✅|
| absen|✅|
| Tagall|✅|
| Hidetag|✅|

| download |🎵|
| ------------- | ------------- |
| play|✅|
| yta|✅|
| ytv|✅|
| tiktok|✅|
| Instagram|✅|
| Twitter|✅|

| islami |🕌|
| ------------- | ------------- |
| Surah <ayat>| ✅|
| Kisah Nabi|✅|
| Jadwal Sholat|✅|

| OTHER |🤗|
| ------------- | ------------- |
| Jadibot|✅|
| Wikipedia|✅|
| Google search|✅|
| Sticker|✅|

| SPECIAL |🔰|
| ------------- | ------------- |
| Bantuan Command |𝗧𝗲𝗿𝘀𝗲𝗱𝗶𝗮|
| Auto Setbio |𝗧𝗲𝗿𝘀𝗲𝗱𝗶𝗮|
| Menyapa Anggota Grup |𝗧𝗲𝗿𝘀𝗲𝗱𝗶𝗮|

# [`👥My Team`](https://chat.whatsapp.com/D75oLHFNUXQCenRThcKUD1)
* [`Fauzan (Dev)`](https://github.com/Fau-Zan)
* [`Ivan (Dev)`](https://github.com/ivan-MLN)
* [`Sanz (Dev)`](https://github.com/sanzgantengz)
* [`Rizky (Creator Rixle Bot)`](https://github.com/Rizxyu)
* [`Arifi Razzaq (Dev)`](https://github.com/Arifirazzaq2001)
* [`O r e k i (Contributor)`](https://github.com/Oreki-san)
* [`ＲｉｘｌｅＢoｔ (Robot)`](https://wa.me/62823283033323)
